const corn = require('node-cron');
const nodeMailer = require('nodemailer');
const emilSenderUtil = require('./EmailSenderUtil/emailSender');
const rmq = require('./rabbitMQ');



// var task = corn.schedule('*/1 * * * *', () =>{
//     emilSenderUtil.SendEmail();
//     console.log('Cron job Strarted : '+datetime.toLocaleTimeString());
// })

//task.start();



// function SendEmail(){
//    try {
//     var datetime = new Date();
//     console.log('Email Sent'+datetime.toLocaleTimeString());


//     const toEmail = "gaganit1265@gmail.com";
//     const subject = "Corn Job Test";
//     const body = "This is Cron Job Notification :"+datetime.toLocaleTimeString();


//     const mailTransPort = nodeMailer.createTransport({
//         //service : 'gmail',
//         host :'smtp.gmail.com',
//         port : '465',
//         auth : {user :'gagantest33@gmail.com' , pass : 'rlgo xicv eyul shdd'}
//     });

//     const mailObj = {
//         from : 'gagantest33@gmail.com',
//         to : toEmail,
//         subject : subject,
//         //text : body,
//         html : '<h1>'+body+'</h1>',
//         attachments : [{filename : 'Report.pdf',path:'C:/Users/gagan/OneDrive/Desktop/Gagan-SE 2.pdf'}]
//     };

//     mailTransPort.sendMail(mailObj,function(err,info){
//         if(err){
//             console.log(err)
//         }else{
//             console.log(info)
//         }
//     })
//    } catch (error) {
//     console.log(error);
//    }
// }