﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OrderAPI.RabbitMQ;
using OrderAPI.Service;
using System.Net;

namespace OrderAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly IBusProxy _busProxy;
        public OrderController(IBusProxy busProxy)
        {
            _busProxy = busProxy;
        }

        [HttpPost]
        public HttpResponseMessage PlaceOrder(Order request)
        {
            OrderService orderService = new OrderService();
            var myOrder = orderService.OrderSubmit(request);
            _busProxy.Send(myOrder, "OrderProcessingExchenage");
            return new HttpResponseMessage(HttpStatusCode.OK);
        }
    }
}
