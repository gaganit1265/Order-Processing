﻿namespace OrderAPI.RabbitMQ
{
    public interface IBusProxy
    {
        public void Send(object message, string queue);
    }
}
