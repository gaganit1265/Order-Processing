﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using System.Text;
using System.Threading.Channels;

namespace OrderAPI.RabbitMQ
{
    public class BusProxy: IBusProxy
    {
        IModel chancel = null;
        public BusProxy()
        {
            #region ---RMQ---

            var factory = new ConnectionFactory()
            {
                HostName = "localhost",
            };

            var connection = factory.CreateConnection();

            chancel = connection.CreateModel();
            #endregion
        }

        public void Send(object message,string exchange)
        {
            string jsonMessage = JsonConvert.SerializeObject(message);
            var meessageByts = Encoding.UTF8.GetBytes(jsonMessage);

            chancel.BasicPublish(exchange: exchange, routingKey: "", basicProperties: null, body: meessageByts);

            Console.WriteLine("Order Placed Succesfully.......Please check order detail on your email..");

        }
    }
}
