using OrderAPI.RabbitMQ;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddTransient<IBusProxy, BusProxy>();
// Add services to the container.

builder.Services.AddControllers();

var app = builder.Build();


// Configure the HTTP request pipeline.

app.UseAuthorization();

app.MapControllers();

app.Run();
