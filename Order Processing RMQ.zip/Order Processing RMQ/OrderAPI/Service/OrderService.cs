﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using System.Diagnostics;
using System.Text;

namespace OrderAPI.Service
{
    public class OrderService
    {
        public Order OrderSubmit(Order request)
        {

            Order orderDetails = new Order() { OrderId = Guid.NewGuid(),Name = request.Name, Category=request.Category,Quantity=request.Quantity,Price=request.Price };
            return orderDetails;
        }
    }

    public class Order
    {
        public Guid OrderId { get; set; }
        public string? Name { get; set; }
        public string? Category { get; set; }
        public int Quantity { get; set; }
        public int Price { get; set; }

    }
}
